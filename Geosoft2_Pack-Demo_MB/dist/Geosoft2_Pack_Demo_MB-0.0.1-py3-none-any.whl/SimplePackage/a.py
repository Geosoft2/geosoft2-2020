def f1():
    print("Das ist das erste Modul")
