def f2():
    print("Das ist das zweite Modul")
